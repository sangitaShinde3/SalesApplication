﻿namespace SalesApplication.Src
{
    public class sales
    {
    }
}
