﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SalesApplication.APIControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesAPIController : ControllerBase
    {

    }
}
